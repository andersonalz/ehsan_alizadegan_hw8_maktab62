$(document).ready(function () {
  $.ajax({
    type: "GET",
    url: "https://restcountries.com/v3.1/all",
    success: function (res) {
      for (let i = 0; i < res.length; i++) {
        $("#countriesSelect").append(`
        <option value="${res[i].cca3}">${res[i].name.common}</option>
        `);
      }
      $("#countriesSelect").change(function (e) {
        e.preventDefault();

        const country = res.find((element) => {
          return element.cca3 === $(this).val();
        });

        showCountryInfo(country);
        getWeather(country.capital[0]);
      });
    },
  });

  const showCountryInfo = (country) => {
    $("#cName").html(` ${country.name.common}`);
    $("#capital").html(` ${country.capital[0]}`);
    $("#region").html(` ${country.region}`);
    $("#population").html(
      ` ${country.population.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`
    );
    $("#languages").html(
      ` ${country.languages[Object.keys(country.languages)[0]]}`
    );
    $("#time-zone").html(
      ` ${country.timezones[Object.keys(country.timezones)[0]]}`
    );
    $("#callingCode").html(` ${country.idd[Object.keys(country.idd)[0]]}`);

    $("#countryImage").attr("src", `${country.flags.svg}`);
  };

  function getWeather(cityName) {
    $.ajax({
      type: "GET",
      url: `https://api.weatherbit.io/v2.0/current?lat=35.7796&lon=-78.6382&key=589c23459fdb430dbefcae0c81e1da0c&include=minutely&appid=d3827f73e279a54118c237d0e8adb461&city=${cityName}`,
      data: "data",
      dataType: "dataType",
      success: function (response) {
        console.log(response);
      },
    });
  }
});
